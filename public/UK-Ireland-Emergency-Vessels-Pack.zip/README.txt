UK & IRELAND EMERGENCY VESSEL REGISTER
Checked 21 November 2026

656 documented vessel records; 497 distinct usable vessel MMSIs.

FILES
UK-Ireland-Emergency-Vessels.csv: full searchable/sortable register with per-record sources, status and original source fields.
UK-Ireland-Emergency-Vessels.json: register and coverage notes.
Verified-MMSI-Watchlist.txt: comma-separated usable identifiers; excludes unresolved conflicts, missing IDs and non-vessel identities. Radio identity does not guarantee AIS carriage.
Category-MMSI-Watchlist.txt: matching category lists.
RNLI-Original-*.json: unmodified official source snapshots.
Police-Fire-Coverage-Notes.json: known individual fleet gaps and exclusions.
ATTRIBUTION.txt: required RNLI attribution and licence.

COVERAGE AND LIMITS
- Coverage spans the United Kingdom, Republic of Ireland, Channel Islands and Isle of Man. It is a public-reference collection, not a guaranteed inventory of every small boat.
- RNLI base: 467 published allocated asset rows across 237 represented stations, including daughter and boarding boats. Source layer data last edited 11 November 2026. This is broader than the headline operational lifeboat count.
- Relief/training craft are added from dated class references because the official allocated dataset excludes temporary relief substitutions. Stations can exchange hulls and call signs.
- RNLI original values are retained in the raw data and source columns. Two entries sharing 235108838 remain unresolved and are excluded from MMSI copies. Arklow 13-53 is cross-referenced to 232025390; source 232054390 is preserved. Hoylake source hull 13-06 / ON1314 / Reg is cross-referenced to 13-07.
- HM Coastguard usually coordinates RNLI and independent lifeboats rather than owning those fleets. The contracted emergency towing vessel Ievoli Black is included separately.
- Irish Coast Guard public information describes RHIB capability in 18 units and D-class capability in 13 units; these are unit counts, not a complete hull inventory. ITU radio identities and public AIS references are distinguished.
- Many police and fire services publish fleet totals or rescue capabilities but do not publish individual names, hull IDs or MMSIs. These gaps are described in the data pack; no anonymous fleet totals have been converted into invented vessels.
- A valid radio MMSI does not establish AIS transmission, current availability or live position. Shore-station identities, SAR aircraft identities, AIS navigation aids and commercial ships sharing rescue-like names are excluded.
- Some records reflect an older official or photographic source; their present status is explicitly unconfirmed. New deliveries, reserves, refits and callsign reuse can change current assignments.
- Official FOI reports 24 vessels as at 24 June 2024. Only individually identified public names are rows; this register is not a complete inventory of all Met inflatables/training boats.
- February 2026 fleet plan: two Atlantic 85 operational rescue boats and two Atlantic 75 reserves being phased out. Older operational call signs/boat names can move, so no extra anonymous aggregate rows created. Verify hull/MMSI associations before merging with former RNLI boats.
- Exclude Cormorant 235104128 from current police list: current owner Northern RIB Hire confirms it bought the vessel from Merseyside underwater unit in 2025. Also excludes predecessor Consortium.
- Official page describes one rigid-hull fire boat and three inflatables operated from Byker / Newcastle Quayside. No public names, hull identifiers or MMSIs established, so aggregate goes here rather than individual fake rows.
- Official operational change pack describes four Clyde rescue boats, two at City of Glasgow College and two at Riverside Museum, operated by Polmadie and Knightswood. Twenty stations have swift water rescue resources. Individual names/hull IDs/MMSIs not established.
- Official procurement/transport pages confirm police boats; public individually identified current hulls and MMSIs not established in this pass.
- Current official station pages identify water rescue boats at Bath and Bedminster, but no unique names/hull IDs or MMSIs collected. Older Firefly hovercraft is not assumed current; official 2025 article describes donation of surplus hovercraft to Ukraine.
- Official 2015 disclosure names 20 police launches plus 28 unnamed RHIBs and two unnamed support boats. Dated inventory is not assumed current; only individually identified boats included in vessel rows.

Contains Open Data licensed under the GIS Open Data Licence
RNLI - Analytics, GIS & Data Science
Licence: https://www.arcgis.com/sharing/rest/content/items/e3c369859c8b490a80d30c54d803e3a1/info/metadata/metadata.xml?format=default&output=html
Original RNLI JSON values retained unchanged; separate presentation labels, public-source cross-references and additional vessel records have been added. This independent register is not affiliated with or endorsed by the RNLI.
